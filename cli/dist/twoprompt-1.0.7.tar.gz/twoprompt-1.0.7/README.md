twoPrompt cli is a cli that allows you to talk with different LLM from the same command line

```pip install twoprompt --break-system-packages```

then run ```prompt```


happy prompting and searching